---
name: RODA.MOTORKU Design System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#44474e'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#465f88'
  primary: '#002046'
  on-primary: '#ffffff'
  primary-container: '#1b365d'
  on-primary-container: '#87a0cd'
  inverse-primary: '#aec7f7'
  secondary: '#54606a'
  on-secondary: '#ffffff'
  secondary-container: '#d8e4f0'
  on-secondary-container: '#5a6670'
  tertiary: '#002805'
  on-tertiary: '#ffffff'
  tertiary-container: '#00400c'
  on-tertiary-container: '#61b15f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#aec7f7'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#2e476f'
  secondary-fixed: '#d8e4f0'
  secondary-fixed-dim: '#bcc8d3'
  on-secondary-fixed: '#111d25'
  on-secondary-fixed-variant: '#3d4852'
  tertiary-fixed: '#a3f69c'
  tertiary-fixed-dim: '#88d982'
  on-tertiary-fixed: '#002204'
  on-tertiary-fixed-variant: '#005312'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: 0em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  currency-stat:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-trust, utilitarian, and commercially grounded aesthetic tailored specifically for Indonesian automotive micro, small, and medium enterprises (UMKM showroom dealers). The platform balances two core jobs-to-be-done: rapid inventory discovery/browsing for retail motorcycle buyers, and high-frequency, precision-driven valuation analytics and management tools for showroom proprietors.

The visual style is **Corporate Modern with High-Legibility Utilitarianism**:
- **Trust & Professionalism:** Built upon deep maritime navies, clean slate borders, and disciplined typography to project appraisal accuracy, operational security, and institutional credibility.
- **Accessibility & Directness:** High-contrast text hierarchies, uncompromised touch targets for multi-device warehouse/showroom floor usage, and direct, conversion-focused actions (such as high-visibility WhatsApp commerce pathways).
- **Data Clarity:** Strict information density and tabular metric readouts designed for quick-scanning prices in Indonesian Rupiah (IDR), mileage stats, and predictive estimation confidence intervals.

## Colors

The palette balances administrative authority with intuitive, transactional legibility. Light mode is the default, ensuring optimal readability in bright outdoor showroom lots and office environments.

### Color Roles
- **Primary Navy (`#1B365D`):** Anchors headers, primary brand marks, navigation sidebars, high-priority buttons, and hero price badges. Establishes institutional strength and machine-learning credibility.
- **Secondary Ice Blue (`#E3EFFB`):** Serves as an atmospheric fill for statistical summary cards, hero banners, filter containers, and informational badge backdrops.
- **Tertiary Forest Green (`#2E7D32`):** Reserved exclusively for positive commercial actions—principally the direct-to-WhatsApp buyer contact triggers, catalog save confirmations, and valuation margin gains.
- **Neutral Canvas (`#F8FAFC` to `#FFFFFF`):** Base surfaces use pure white (`#FFFFFF`) for operational cards and inputs, backed by subtle slate (`#F8FAFC`) canvas fills and structured slate borders (`#E2E8F0` and `#CBD5E1`) for spatial rhythm without visual noise.
- **System Accents:** High-alert badge reds (`#D32F2F`) for out-of-stock items, amber (`#ED6C02`) for pending valuations, and deep slate (`#334155`) for standard neutral body typography.

## Typography

The typography is powered exclusively by **Inter**, leveraging its tall x-height, distinct open counters, and exceptional tabular numeric figures.

### Typographic Rules
- **Monetary & Numeric Purity:** All vehicle prices, valuation estimates, and kilometer tallies must use CSS `font-feature-settings: "tnum" 1` (tabular figures) to guarantee precise alignment across data tables and inventory cards.
- **Hierarchy & Weight:** Restrict body weights to Regular (400) and SemiBold (600), with Bold (700) reserved exclusively for headlines, calculated valuation sums, and key vehicle metrics.
- **Indonesian Currency Conventions:** Indonesian Rupiah formatting must always bind prefix `Rp` to the figure using a non-breaking space (e.g., `Rp 18.500.000`) styled with consistent numeric weight.

## Layout & Spacing

The layout follows a responsive 12-column grid built for intense computational tables, high-density inventory browsing, and quick single-column mobile views:

- **Desktop (≥ 1024px):** 12-column fluid grid, `2rem` page margins, `1.5rem` gutters. Admin dashboard uses a fixed 260px vertical sidebar with a dynamic flex-flow main content canvas.
- **Tablet (768px – 1023px):** 8-column layout, `1.5rem` margins, `1rem` gutters. Sidebars collapse into icon rails or slide-over drawer menus.
- **Mobile (< 768px):** 4-column layout, `1rem` margins, `0.75rem` to `1rem` gutters. Complex tables shift to horizontal swipe containers or expand-to-inspect card stacks.

Vertical rhythm is governed by multiples of `0.25rem` (4px / 8px baseline rhythm). Component gaps conform strictly to `space-sm` (8px) for related form items and `space-md` (16px) for distinct operational groups.

## Elevation & Depth

To preserve an ultra-clean, high-speed administrative feel, depth is communicated through **structural borders and soft ambient drops**, avoiding exaggerated neo-brutalist heavy lines or excessive glassmorphic blurs.

### Surface Tiers
- **Tier 0 (Canvas Base):** Background canvas rendered in `#F8FAFC`. Completely flat.
- **Tier 1 (Resting Cards & Tables):** Solid `#FFFFFF` surfaces bounded by a hairline 1px border of `#E2E8F0`. No shadow required in standard states.
- **Tier 2 (Interactive Floating & Metric Cards):** Subtle, tinted elevation for hover states and ML result callouts:
  `box-shadow: 0 4px 12px -2px rgba(27, 54, 93, 0.06), 0 2px 4px -1px rgba(27, 54, 93, 0.04);`
- **Tier 3 (Modals, Calculation Popovers & Drawers):** Focused operational elevation:
  `box-shadow: 0 12px 32px -4px rgba(27, 54, 93, 0.12), 0 4px 8px -2px rgba(27, 54, 93, 0.04);`
  Paired with a slate backdrop overlay (`#0F172A` at 40% opacity).

## Shapes

The design system adopts a **Soft (Level 1)** corner geometry, featuring a baseline radius of `0.25rem` (4px), scaling to `0.5rem` (8px) on cards and input fields, and `0.75rem` (12px) on prominent analytics modals.

This low-radius structure projects geometric rigor, precision engineering, and maximized usable screen area—critical for high-density inventory data tables and side-by-side vehicle comparison matrices. Circular pills (`rounded-full`) are reserved solely for status chips, transmission tags, and count badges.

## Components

### Buttons
- **Primary:** Solid `#1B365D` background, `#FFFFFF` text, `0.25rem` border-radius, minimum 44px touch height. Hover shifts to `#132742`.
- **Secondary:** Subtle `#E3EFFB` background with `#1B365D` text and no border. Hover shifts to `#D2E4F7`.
- **WhatsApp Direct Action:** Dedicated commercial button featuring `#2E7D32` background, white label, and official messaging icon. Positioned as high-visibility sticky action on mobile vehicle cards.
- **Outline / Filter:** Crisp 1px border `#CBD5E1`, transparent background, dark slate text.

### Form Inputs & Selectors
- Background: `#FFFFFF`. Border: 1px `#CBD5E1`. Roundedness: `0.375rem`.
- Focus State: 2px ring in primary Navy (`#1B365D`) with zero vertical element shift.
- Currency Inputs: Fixed prefix box (`Rp`) filled with `#F1F5F9`, right-aligned numeric tabular entry with thousand separators.

### Product Cards (Vehicle Inventory)
- Contained within 1px `#E2E8F0` border on pure white background.
- Image ratio: 16:10 with lazy-load skeleton state and mileage/year pill overlays.
- Footer features bold tabular pricing (`currency-stat`), verification check badge, and dual actions: "Detail & Spek" outline button + direct WhatsApp green button.

### Machine Learning Price Prediction Panel
- Prominently boxed with `#E3EFFB` background and `#1B365D` accent trim.
- Instant valuation outputs highlight estimated market ranges (e.g., `Rp 14.200.000 - Rp 15.000.000`) alongside confidence indicators and showroom margin guidance.

### Data Tables (Inventory Management)
- Dense, zebra-hover rows on `#FFFFFF` against `#F8FAFC` headers.
- Fixed header support, sorting icons on column caps, sticky status column, and monospaced engine chassis number fields.